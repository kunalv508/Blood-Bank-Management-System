$(document).ready(function(){
	$('#register-form').validate();
	$('#login-form').validate();
	$('#myTable').DataTable();
	$('#myTable1').DataTable();


});