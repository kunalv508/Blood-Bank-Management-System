<?php
/**
 * Static content controller.
 *
 * This file will render views from views/homes/
 *
 * CakePHP(tm) : Rapid Development Framework (https://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (https://cakefoundation.org)
 * @link          https://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       https://opensource.org/licenses/mit-license.php MIT License
 */

App::uses('AppController', 'Controller');

/**
 * Static content controller
 *
 * Override this controller by placing a copy in controllers directory of an application
 *
 * @package       app.Controller
 * @link https://book.cakephp.org/2.0/en/controllers/pages-controller.html
 */
class HomesController extends AppController {

/**
 * This controller does not use a model
 *
 * @var array
 */
	public $uses = array('User','BloodGroup','City','BloodBank','Hospital','BloodRequest','BloodResponse','UserRequest','UserResponse');
	public $layout = 'public';
	public $Component = array('Html','Session','Flash');
	public $helper = array('Html','Session','Flash');
/**
 * Displays a view
 *
 * @return CakeResponse|null
 * @throws ForbiddenException When a directory traversal attempt.
 * @throws NotFoundException When the view file could not be found
 *   or MissingViewException in debug mode.
 */
	public function index() {
		$bloodGroups = $this->BloodGroup->findAllByStatus(1);
		$cities = $this->City->findAllByStatus(1);
		$this->set(compact('bloodGroups','cities'));
	}
	public function register() {
		$bloodGroups = $this->BloodGroup->findAllByStatus(1);
		$cities = $this->City->findAllByStatus(1);
		$bloodBank = $this->BloodBank->find('all');
		$this->set(compact('bloodGroups','cities','bloodBank'));
		if($this->request->is('post') && !empty($this->data)){

			$data = $this->data;
			$data['password'] = md5($this->data['password']);
			try{
				$this->User->save($data);
			}catch(Exception $e){
				//pr($e);die;
				$this->Flash->success('Duplicate entry for contact '.$data['phone'].' not allowed.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Registration successful.Please login.');
			$this->redirect(array('controller' => '','action' => 'loginStep.html'));
		}
	}
	public function login() {
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			if($data['type'] == 'User')
			$loginData = $this->User->find('first',array(
													'conditions' => array(
																	'phone' => $data['phone'],
																	'password' => md5($data['password'])
																		)
														)
											);
			else if($data['type'] == 'Manager')
				$loginData = $this->BloodBank->find('first',array(
													'conditions' => array(
																	'phone' => $data['phone'],
																	'password' => md5($data['password'])
																		)
														)
											);
			else
				$loginData = $this->Hospital->find('first',array(
													'conditions' => array(
																	'phone' => $data['phone'],
																	'password' => md5($data['password'])
																		)
														)
											);

			if(!empty($loginData)){
				$loginData['loginType'] = $data['type'];
				if($data['type'] == 'User'){
					$this->Session->write('User',$loginData['User']);
					$this->redirect(array('action'=>'userDashboard'));
				}
				else if($data['type'] == 'Manager'){
					$this->Session->write('User',$loginData['BloodBank']);
					$this->redirect(array('action'=>'managerDashboard'));
				}
				else{
					$this->Session->write('User',$loginData['Hospital']);
					$this->redirect(array('action'=>'hospitalDashboard'));
				}
			}
			$this->Flash->error('Invalid contact/password.Please try again.');
			$this->redirect(array('controller' => '','action' => 'loginStep.html'));
		}
	}
	public function search(){
		$bloodGroupId = base64_decode($_GET['blood']);
		$cityId = base64_decode($_GET['city']);
		$this->User->bindModel(array(
					'belongsTo' => array(
							'BloodGroup' => array(
									'className' => 'BloodGroup',
									'foreignKey' => 'blood_group_id'
								)
						)
				)
			);
		$this->User->bindModel(array(
					'belongsTo' => array(
							'City' => array(
									'className' => 'City',
									'foreignKey' => 'city_id'
								)
						)
				)
			);
		$searchData = $this->User->find('all',array(
					'conditions' => array(
							'blood_group_id' => $bloodGroupId,
							'city_id' => $cityId
						)
				)
			);
		$this->set(compact('searchData'));
	}
	public function registerStep(){

	}
	public function loginStep(){

	}
	public function bloodBank(){
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			$data['password'] = md5($this->data['password']);
			$data['type'] = 0;
			try{
				$this->BloodBank->save($data);
			}catch(Exception $e){
				$this->Flash->success('Duplicate entry for contact/Email not allowed.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Manager Registration successful.Please login.');
			$this->redirect(array('controller' => '','action' => 'loginStep.html'));
		}
	}
	public function hospital(){
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			$data['password'] = md5($this->data['password']);
			try{
				$this->Hospital->save($data);
			}catch(Exception $e){
				$this->Flash->success('try again.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Hospital Registration successful.Please login.');
			$this->redirect(array('controller' => '','action' => 'loginStep.html'));
		}
	}

	public function hospitalDashboard(){
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'BloodGroup' => array(
									'className' => 'BloodGroup',
									'foreignKey' => 'blood_group_id'
								)
						)
				)
			);
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'City' => array(
									'className' => 'City',
									'foreignKey' => 'city_id'
								)
						)
				)
			);
		$requestData = $this->BloodRequest->find('all',array(
					'conditions' => array(
							'hospital_id' => $this->Session->read('User.id')
						)
				)
			);
		$this->set(compact('requestData'));
	}

	public function	bloodRequest(){
		$bloodGroups = $this->BloodGroup->findAllByStatus(1);
		$cities = $this->City->findAllByStatus(1);
		$this->set(compact('bloodGroups','cities'));
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			$data['hospital_id'] = $this->Session->read('User.id');
			try{
				$this->BloodRequest->save($data);
			}catch(Exception $e){
				$this->Flash->success('try again.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Request send to all blood banks.');
			$this->redirect(array('action'=>'hospitalDashboard'));
		}
	}
	public function logout(){
		$this->Session->destroy();
		$this->redirect(array('controller' => '','action' => 'loginStep.html'));
	}

	public function bloodResponse($requestId = null){
		$requestId = base64_decode($requestId);
		$this->BloodResponse->bindModel(array(
					'belongsTo' => array(
							'BloodBank' => array(
									'className' => 'BloodBank',
									'foreignKey' => 'blood_bank_id'
								)
						)
				)
			);
		$responseData = $this->BloodResponse->findAllByBloodRequestId($requestId);
		$this->set(compact('responseData'));
	}

	public function managerDashboard(){
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'BloodGroup' => array(
									'className' => 'BloodGroup',
									'foreignKey' => 'blood_group_id'
								)
						)
				)
			);
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'City' => array(
									'className' => 'City',
									'foreignKey' => 'city_id'
								)
						)
				)
			);
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'Hospital' => array(
									'className' => 'Hospital',
									'foreignKey' => 'hospital_id'
								)
						)
				)
			);
		$this->BloodRequest->bindModel(array(
					'hasOne' => array(
							'UserRequest' => array(
									'className' => 'UserRequest',
									'foreignKey' => 'request_id'
								)
						)
				)
			);
		$requestData = $this->BloodRequest->findAllByStatus(0);
		$this->set(compact('requestData','receptionists'));
	}
	public function bloodRequestClose($requestId = null){
		$this->BloodRequest->id = base64_decode($requestId);
		$this->BloodRequest->saveField('status',1);
		$this->redirect(array('action' => 'hospitalDashboard'));
	}
	public function bloodRequestResponse($requestId = null){
		$requestId= base64_decode($requestId);
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'BloodGroup' => array(
									'className' => 'BloodGroup',
									'foreignKey' => 'blood_group_id'
								)
						)
				)
			);
		$this->BloodRequest->bindModel(array(
					'belongsTo' => array(
							'Hospital' => array(
									'className' => 'Hospital',
									'foreignKey' => 'hospital_id'
								)
						)
				)
			);
		$bloodRequest = $this->BloodRequest->findById($requestId);
		$this->set(compact('bloodRequest'));
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			$data['blood_bank_id'] = $this->Session->read('User.id');
			$data['blood_request_id'] = $requestId;
			try{
				$this->BloodResponse->save($data);
			}catch(Exception $e){
				$this->Flash->success('try again.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Resposne send to Hospital.');
			$this->redirect(array('action'=>'managerDashboard'));
		}
	}
/*	public function addReceptioninst(){
		if($this->request->is('post') && !empty($this->data)){
			$data = $this->data;
			$data['parent_id'] = $this->Session->read('User.id');
			try{
				$this->BloodResponse->save($data);
			}catch(Exception $e){
				$this->Flash->success('try again.');
				$this->redirect($this->referer());
			}
			$this->Flash->success('Resposne send to Hospital.');
			$this->redirect(array('action'=>'managerDashboard'));
		}
	}*/

	public function SendRequestUser($requestId = null){
		$requestId = base64_decode($requestId);
		$reqData = $this->BloodRequest->findById($requestId);
		$data['request_id'] = $requestId;
		$data['blood_group_id'] = $reqData['BloodRequest']['blood_group_id'];
		$data['blood_bank_id'] = $this->Session->read('User.id');
		$check = $this->UserRequest->find('first',array(
					'conditions' => array(
							'request_id' => $requestId,
							'blood_bank_id' => $this->Session->read('User.id')
						)
				)
			);
		if(empty($check)){
			$this->UserRequest->save($data);
			$this->Flash->success('Request send to users.');
		}
		else
			$this->Flash->success('Request already sent.');
		
		$this->redirect(array('action'=>'managerDashboard'));

	}
	public function closeRequestUser($requestId = null){
		$check = $this->UserRequest->find('first',array(
					'conditions' => array(
							'request_id' => base64_decode($requestId),
							'blood_bank_id' => $this->Session->read('User.id')
						)
				)
			);
		$check['UserRequest']['status'] = 1;
		$this->UserRequest->save($check);
		$this->Flash->success('Request closed successfully.');
		$this->redirect(array('action' => 'managerDashboard'));
	}
	public function userDashboard(){
		$this->UserRequest->bindModel(array(
					'belongsTo' => array(
							'BloodGroup' => array(
									'className' => 'BloodGroup',
									'foreignKey' => 'blood_group_id'
								)
						)
				)
			);
		$this->UserRequest->bindModel(array(
					'hasOne' => array(
							'UserResponse' => array(
									'className' => 'UserResponse',
									'foreignKey' => 'user_request_id'
								)
						)
				)
			);
		$this->UserRequest->bindModel(array(
					'belongsTo' => array(
							'BloodBank' => array(
									'className' => 'BloodBank',
									'foreignKey' => 'blood_bank_id'
								)
						)
				)
			);
		$this->UserRequest->bindModel(array(
					'belongsTo' => array(
							'BloodRequest' => array(
									'className' => 'BloodRequest',
									'foreignKey' => 'request_id'
								)
						)
				)
			);
		$requestData = $this->UserRequest->find('all',array(
					'conditions' => array(
							'UserRequest.blood_bank_id' => $this->Session->read('User.blood_bank_id'),
							'UserRequest.blood_group_id' => $this->Session->read('User.blood_group_id'),
							'UserRequest.status' => 0
						)
				)
			);
		$bloodGroup = $this->BloodGroup->findById($this->Session->read('User.blood_group_id'));
		$this->set(compact('requestData','bloodGroup'));
	}

	public function userRequestResponse($userRequestId = null,$bloodRequestId = null){
		$data['user_request_id'] = base64_decode($userRequestId);
		$data['blood_request_id'] = base64_decode($bloodRequestId);
		$data['user_id'] = $this->Session->read('User.id');
		$this->UserResponse->save($data);
		$this->Flash->success('Confirmation sent to blood bank.');
		$this->redirect(array('action' => 'userDashboard'));

	}

	public function userResponse($bloodRequestId = null){
		$bloodRequestId = base64_decode($bloodRequestId);
		$this->UserResponse->bindModel(array(
					'belongsTo' => array(
							'User' => array(
									'className' => 'User',
									'foreignKey' => 'user_id'
								)
						)
				)
			);
		$this->UserResponse->bindModel(array(
					'belongsTo' => array(
							'BloodRequest' => array(
									'className' => 'BloodRequest',
									'foreignKey' => 'blood_request_id'
								)
						)
				)
			);
		$requestData = $this->UserResponse->find('all',array(
								'conditions' => array(
										'blood_request_id' => $bloodRequestId
									)
							)
						);
		$this->set(compact('requestData'));
	}

	public function delete($model = null ,$id = null){
		$this->$model->delete($id);
		$this->redirect($this->referer());
	}
}
